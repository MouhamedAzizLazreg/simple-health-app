import { useState } from "react";
const friends = [];

export default function App() {
  const [friendList, setFriendList] = useState(friends);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [selecteFriend, setSelectedFriend] = useState(null);
  function handleAddFriends(friend) {
    setFriendList((friendList) => [...friendList, friend]);
  }

  function handleShowAddFriends() {
    setShowAddFriend((show) => !show);
  }
  function handleSelection(friend) {
    setSelectedFriend((cur) => (cur?.id === friend.id ? null : friend));
  }
  function handleMenu(value) {
    setFriendList((friendList) =>
      friendList.map((friend) =>
        friend.id === selecteFriend.id
          ? {
              ...friend,
              mentalHealth: Math.round(
                (selecteFriend.mentalHealth + value) / 2
              ),
            }
          : friend
      )
    );
  }
  function handleDelete() {
    setFriendList(
      friendList.filter((friend) => friend.id !== selecteFriend.id)
    );
    const confirmed = window.confirm("are u sure about dis shit?");
  }
  return (
    <>
      <h1>🌌Mental Health Tracker🌌</h1>
      <div className="app">
        <div className="sidebar">
          <Users
            friends={friendList}
            onSelection={handleSelection}
            selectedFriend={selecteFriend}
            onDelete={handleDelete}
          />
          <Button onClick={handleShowAddFriends}>Add a friend</Button>
          {showAddFriend && <AddUser onAddfriend={handleAddFriends} />}
        </div>
        {selecteFriend && (
          <MoodMenu selecteFriend={selecteFriend} onHandleMenu={handleMenu} />
        )}
      </div>
    </>
  );
}

function Users({ friends, onSelection, selectedFriend, onDelete }) {
  return (
    <ul>
      {friends.map((friend) => (
        <Friend
          key={friend.id}
          onSelection={onSelection}
          selecteFriend={selectedFriend}
          friend={friend}
          onDelete={onDelete}
        />
      ))}
    </ul>
  );
}
function Friend({ friend, onSelection, selecteFriend, onDelete }) {
  const isSelected = selecteFriend?.id === friend.id;
  return (
    <li className={isSelected ? "selected" : ""}>
      <h3> 🤩My friend {friend.name}🤩</h3>
      <p>
        {friend.name}'s mental health is at ⭐{friend.mentalHealth}%⭐
      </p>
      <Button onClick={() => onSelection(friend)}>
        {isSelected ? "close" : "select"}
      </Button>
      <Button onClick={() => onDelete(friend)}>Delete</Button>
    </li>
  );
}

function AddUser({ onAddfriend }) {
  const [name, setName] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!name) return;
    const id = crypto.randomUUID();
    const newFriend = {
      id,
      name,
      mentalHealth: 100,
    };
    onAddfriend(newFriend);
    setName("");
  }
  return (
    <div className="adding">
      <form className="form-add-friend" onSubmit={handleSubmit}>
        <h2>Add A friend:</h2>
        <input
          type="text"
          placeholder="Friend's name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </form>
    </div>
  );
}

function Button({ children, onClick }) {
  return (
    <button className="button" onClick={onClick}>
      {children}
    </button>
  );
}
function MoodMenu({ selecteFriend, onHandleMenu }) {
  const [happiness, setHappiness] = useState("");
  const [Energie, setEnergie] = useState("");
  const [stress, setStress] = useState("");
  const [sadness, setSadness] = useState("");
  const [madness, setMadness] = useState("");
  const [loneliness, setLoneliness] = useState("");
  const [relation, setRelation] = useState("");
  function handleSubmit(e) {
    e.preventDefault();
    const value =
      (happiness +
        Energie +
        (100 - stress) +
        (100 - sadness) +
        (100 - madness) +
        (100 - loneliness) +
        relation) /
      7;
    onHandleMenu(value);
  }

  return (
    <div>
      <h3> Today's {selecteFriend?.name} Mood</h3>
      <form className="form-split-bill" onSubmit={handleSubmit}>
        <label>😺 Happiness</label>
        <input
          type="text"
          value={happiness}
          onChange={(e) =>
            setHappiness(
              Number(e.target.value) > 100 ? happiness : Number(e.target.value)
            )
          }
        />

        <label>🔋 Energie</label>
        <input
          type="text"
          value={Energie}
          onChange={(e) =>
            setEnergie(
              Number(e.target.value) > 100 ? Energie : Number(e.target.value)
            )
          }
        />

        <label>😵stress</label>
        <input
          type="text"
          value={stress}
          onChange={(e) =>
            setStress(
              Number(e.target.value) > 100 ? stress : Number(e.target.value)
            )
          }
        />

        <label>😞 sadness</label>
        <input
          type="text"
          value={sadness}
          onChange={(e) =>
            setSadness(
              Number(e.target.value) > 100 ? sadness : Number(e.target.value)
            )
          }
        />

        <label>😡 madness</label>
        <input
          type="text"
          value={madness}
          onChange={(e) =>
            setMadness(
              Number(e.target.value) > 100 ? madness : Number(e.target.value)
            )
          }
        />

        <label>👦 lonelliness</label>
        <input
          type="text"
          value={loneliness}
          onChange={(e) =>
            setLoneliness(
              Number(e.target.value) > 100 ? loneliness : Number(e.target.value)
            )
          }
        />
        <label>👪 Relation with family</label>
        <select
          value={relation}
          onChange={(e) => setRelation(Number(e.target.value))}
        >
          <option value="0">Trash</option>
          <option value="25">Decent</option>
          <option value="50">Mid</option>
          <option value="75">good</option>
          <option value="100">Excellent</option>
        </select>
        <Button>Submit</Button>
      </form>
    </div>
  );
}
function AverageMentalHealth() {}
